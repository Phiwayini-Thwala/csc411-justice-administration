# CSC411 Member 1 deliverables

## Contents
- `database/`: SQLite schema scripts and clearly labelled sample records for each service.
- `frontend/index.html`: responsive HTML/JavaScript prototype with demo mode and optional API mode.
- `CSC411_Presentation.pptx`: editable presentation slides.

## Run the frontend
Open `frontend/index.html` in a browser. Demo mode is enabled by default. Click **Use demo data** to reload the sample workflow.

To try live mode, start the team's FastAPI services on ports 8001, 8002 and 8003, then turn off Demo mode. The endpoint paths and JSON field names in `index.html` are assumptions and must be aligned with the team's final OpenAPI contract. Browser CORS must also be enabled by the services.

## Database notes
Each organisation owns its database. Cross-service references are stored as external case numbers rather than cross-database foreign keys. Run each SQL file against a separate SQLite database. Sample data is illustrative only.

## Important
The frontend is a prototype. Do not use real personal or criminal case data in a classroom demo. Confirm the official process, access rules, API contract and database fields with the team before submission.
