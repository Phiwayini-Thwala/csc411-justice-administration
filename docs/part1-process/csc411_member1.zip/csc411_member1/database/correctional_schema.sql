PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS inmates (
  inmate_id INTEGER PRIMARY KEY AUTOINCREMENT,
  court_case_number TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  admission_date TEXT,
  facility TEXT,
  sentence_summary TEXT,
  status TEXT NOT NULL DEFAULT 'Admitted',
  release_date TEXT
);
CREATE TABLE IF NOT EXISTS inmate_transfers (
  transfer_id INTEGER PRIMARY KEY AUTOINCREMENT,
  inmate_id INTEGER NOT NULL REFERENCES inmates(inmate_id),
  from_facility TEXT,
  to_facility TEXT NOT NULL,
  transfer_date TEXT NOT NULL,
  reason TEXT
);
CREATE TABLE IF NOT EXISTS correctional_audit_log (
  audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  inmate_id INTEGER REFERENCES inmates(inmate_id),
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO inmates(inmate_id,court_case_number,full_name,admission_date,facility,sentence_summary,status)
 VALUES (1,'POL-1003','Demo Suspect C','2026-11-01','Demo Facility','Sample sentence','Admitted');
