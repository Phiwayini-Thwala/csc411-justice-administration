PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS court_cases (
  court_case_id INTEGER PRIMARY KEY AUTOINCREMENT,
  police_case_number TEXT NOT NULL UNIQUE,
  suspect_name TEXT NOT NULL,
  charges_summary TEXT NOT NULL,
  received_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  hearing_date TEXT,
  hearing_location TEXT,
  bail_or_remand TEXT,
  verdict TEXT,
  sentence TEXT,
  status TEXT NOT NULL DEFAULT 'Received'
);
CREATE TABLE IF NOT EXISTS court_audit_log (
  audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  court_case_id INTEGER REFERENCES court_cases(court_case_id),
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO court_cases(court_case_id,police_case_number,suspect_name,charges_summary,status)
 VALUES (1,'POL-1002','Demo Suspect B','Assault (sample)','Hearing scheduled');
