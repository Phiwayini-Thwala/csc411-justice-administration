PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS suspects (
  suspect_id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  reference_number TEXT UNIQUE,
  date_of_birth TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS police_cases (
  case_id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_number TEXT NOT NULL UNIQUE,
  suspect_id INTEGER NOT NULL REFERENCES suspects(suspect_id),
  alleged_offence TEXT NOT NULL,
  arrest_date TEXT,
  police_station TEXT,
  status TEXT NOT NULL DEFAULT 'Registered',
  referred_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS charges (
  charge_id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_id INTEGER NOT NULL REFERENCES police_cases(case_id) ON DELETE CASCADE,
  charge_description TEXT NOT NULL,
  statute_reference TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS police_audit_log (
  audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO suspects(suspect_id,full_name,reference_number) VALUES
 (1,'Demo Suspect A','DEMO-001'),(2,'Demo Suspect B','DEMO-002');
INSERT OR IGNORE INTO police_cases(case_id,case_number,suspect_id,alleged_offence,status)
 VALUES (1,'POL-1001',1,'Theft (sample)','Registered'),(2,'POL-1002',2,'Assault (sample)','Referred');
