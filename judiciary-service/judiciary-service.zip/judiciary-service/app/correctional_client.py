"""HTTP client for the Correctional service (the only service the Judiciary
calls). 5-second timeout, forwards the caller's JWT (design 6.2, 11).

Every method raises BadGatewayError when the Correctional service is
unreachable or fails, so the caller saves nothing in its own database
(design 11: fail without partial updates)."""
import logging
from typing import Optional

import httpx

from .errors import BadGatewayError, ConflictError

log = logging.getLogger("judiciary.correctional")


class CorrectionalClient:
    def __init__(self, base_url: str, timeout: float = 5.0, client: Optional[httpx.Client] = None):
        self.base_url = base_url.rstrip("/")
        self.http = client or httpx.Client(timeout=timeout)

    # ----- plumbing -----
    def _call(self, method: str, path: str, token: str, user: str, body: dict) -> httpx.Response:
        url = f"{self.base_url}{path}"
        try:
            resp = self.http.request(method, url, json=body, headers={"Authorization": f"Bearer {token}"})
        except httpx.TimeoutException:
            log.warning("user=%s %s %s -> timeout", user, method, url)
            raise BadGatewayError("The Correctional service did not respond in time; try again later")
        except httpx.HTTPError as exc:
            log.warning("user=%s %s %s -> %s", user, method, url, exc.__class__.__name__)
            raise BadGatewayError("The Correctional service is unavailable; try again later")
        log.info("user=%s %s %s -> %s", user, method, url, resp.status_code)
        return resp

    @staticmethod
    def _message(resp: httpx.Response) -> str:
        try:
            return str(resp.json().get("message", ""))
        except (ValueError, AttributeError):
            return ""

    def _fail(self, resp: httpx.Response, what: str):
        detail = self._message(resp)
        if resp.status_code == 409:      # e.g. court case already has an inmate / inmate already released
            raise ConflictError(f"Correctional service refused the {what}: {detail or 'conflict'}")
        raise BadGatewayError(
            f"The Correctional service rejected the {what} (HTTP {resp.status_code})"
            + (f": {detail}" if detail else ""))

    # ----- operations (design 5.4) -----
    def admit(self, payload: dict, token: str, user: str) -> str:
        """POST /inmates -> inmate_id"""
        resp = self._call("POST", "/inmates", token, user, payload)
        if resp.status_code != 201:
            self._fail(resp, "admission")
        try:
            inmate_id = resp.json()["inmate_id"]
        except (ValueError, KeyError, TypeError):
            raise BadGatewayError("The Correctional service returned an unexpected response")
        if not isinstance(inmate_id, str) or not inmate_id:
            raise BadGatewayError("The Correctional service returned an unexpected response")
        return inmate_id

    def set_convicted(self, inmate_id: str, sentence_months: int, token: str, user: str) -> None:
        """PUT /inmates/{id}/status -> CONVICTED"""
        resp = self._call("PUT", f"/inmates/{inmate_id}/status", token, user,
                          {"status": "CONVICTED", "sentence_months": sentence_months})
        if resp.status_code != 200:
            self._fail(resp, "status update")

    def release(self, inmate_id: str, reason: str, notes: Optional[str], token: str, user: str) -> None:
        """POST /inmates/{id}/release (ACQUITTED, BAIL_GRANTED or COURT_ORDER)"""
        body = {"reason": reason}
        if notes:
            body["notes"] = notes
        resp = self._call("POST", f"/inmates/{inmate_id}/release", token, user, body)
        if resp.status_code != 200:
            self._fail(resp, "release order")
